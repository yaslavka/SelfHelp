export const structure = {
  ref1: [
    {
      id: 1,
      name: 'Name Surename',
      ref2: [
        {
          id: 2,
          name: 'Name Surename',
          ref3: [
            {
              id: 3,
              name: 'Name Surename',
            },
          ],
        },
      ],
    },
    {
      id: 4,
      name: 'Name Surename',
      ref2: [
        {
          id: 5,
          name: 'Name Surename',
          ref3: [
            {
              id: 6,
              name: 'Name Surename',
            },
          ],
        },
      ],
    },
  ],
};
